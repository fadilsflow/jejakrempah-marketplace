ALTER TABLE "order" ADD COLUMN "buyer_service_fee" numeric(10,2) DEFAULT '0.00' NOT NULL;
